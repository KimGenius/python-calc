input_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
map_list = map(lambda x: 2 * x + 1, input_list)
print(list(map_list))
