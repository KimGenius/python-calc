year = int(input("연도를 입력하세요: "))

result = year % 12

if result == 0:
    print("원숭이띠")
elif result == 1:
    print("닭띠")
elif result == 2:
    print("개띠")
elif result == 3:
    print("돼지띠")
elif result == 4:
    print("쥐띠")
elif result == 5:
    print("소띠")
elif result == 6:
    print("호랑이띠")
elif result == 7:
    print("토끼띠")
elif result == 8:
    print("용띠")
elif result == 9:
    print("뱀띠")
elif result == 10:
    print("말띠")
elif result == 11:
    print("양띠")
